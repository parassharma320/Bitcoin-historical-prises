use amazon 
select*from  [dbo].[bitcoin_2010-07-27_2024-04-25 (1)]

select *
from [dbo].[bitcoin_2010-07-27_2024-04-25 (1)]
where [Volume] is  not null ;

select *
from [dbo].[bitcoin_2010-07-27_2024-04-25 (1)]
where[Market_Cap] is  not null ;

